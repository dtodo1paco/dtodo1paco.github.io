# test-audio-cc

Exercise 3 of job application

## Running Locally

Make sure you have [Node.js](http://nodejs.org/)  installed.

```sh
npm install
npm start
```

Your app should now be running on [localhost:5000](http://localhost:5000/).


## Documentation
